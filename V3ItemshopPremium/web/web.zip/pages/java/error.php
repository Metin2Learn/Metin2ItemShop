<div id="error" class="contrast-box">
	<div class="dark-grey-box">
		<h2><i class="icon-info left"></i><?php print $lang_shop['error']; ?></h2>
		<p><?php print $lang_shop['error-occurred']; ?></p>
		<h3><?php print $lang_shop['what-do-error']; ?></h3>
		<ul class="clearfix">
			<li><?php print $lang_shop['try-error']; ?></li>
		</ul>
		<div class="btn_wrapper"></div>
	</div>
</div>
