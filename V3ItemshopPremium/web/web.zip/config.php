<?php
	//Shop url
	$shop_url = "http://localhost/shop/";
	
	$shop_title = "Metin2CMS";
	$game_ishop_key = "GF9001";
		
	//Game database
	$game_mysql = [		'host'		=> 'localhost',
						'user' 		=> 'root',
						'password'	=> '',
						'port'      => 3306
	];
	//Shop database
	$shop_mysql = [		'host'		=> 'localhost',
						'database' 	=> 'shop',
						'user' 		=> 'root',
						'password'	=> '',
						'port'      => 3306
	];
	
	$license = "74FAY-4YLV7-W83B4-NEGW5";